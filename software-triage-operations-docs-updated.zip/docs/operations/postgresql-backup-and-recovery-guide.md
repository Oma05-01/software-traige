# PostgreSQL Backup and Recovery Guide

## 1. Purpose

This guide describes a practical backup and recovery pattern for PostgreSQL running in Kubernetes. It covers more than producing a dump: a usable backup process must create a consistent archive, store it somewhere durable, validate it, copy it outside the cluster, and periodically prove that it can be restored.

The reference implementation is the Software Triage Team application in the `software-triage` namespace, using PostgreSQL 18.6 on a single-node Docker Desktop Kubernetes cluster.

## 2. Recovery objectives and scope

The implementation aims to provide:

- scheduled logical backups of the application database;
- archive validation before a backup is treated as complete;
- checksums for transfer/integrity verification;
- an in-cluster backup volume separate from the database PVC;
- an external Windows copy;
- a tested restore path into a separate database;
- a retention policy for in-cluster archives.

This is a development-environment recovery pattern, not a complete production disaster-recovery architecture. In particular, Docker Desktop hostpath storage is not independent of the host or cluster.

### What a PostgreSQL database dump does and does not cover

A `pg_dump` archive covers one database. It does not automatically back up:

- PostgreSQL cluster-wide roles and other global objects (use a deliberate `pg_dumpall --globals-only` or managed equivalent if needed);
- Kubernetes Secrets, ConfigMaps, deployment manifests, or certificates;
- Redis data/queues;
- user-uploaded files stored outside PostgreSQL;
- external services, API credentials, or provider-side state;
- the Docker Desktop VM, host disk, or cluster itself.

Document and back up those dependencies separately. Never assume a PostgreSQL dump alone is a complete application recovery package.

## 3. Reference backup architecture

```text
PostgreSQL StatefulSet
        |
        | pg_dump (custom archive)
        v
Kubernetes CronJob (every 6 hours)
        |
        | write partial -> validate -> rename final -> checksum
        v
Dedicated postgres-backups PVC (2Gi, hostpath, PV reclaim policy Retain)
        |
        | read-only mount
        v
postgres-backup-exporter Deployment
        |
        | kubectl cp + SHA256 verification
        v
Windows PowerShell export script
        |
        v
Repository backups/ directory (gitignored)
```

The CronJob and backup PVC are inside the same Kubernetes cluster. The Windows copy is outside the cluster's Pod/PVC lifecycle, but it remains on the same physical Windows machine unless copied elsewhere.

## 4. Backup storage design

### Dedicated PVC

The project uses a separate `postgres-backups` PVC with:

| Setting | Value |
|---|---|
| Capacity | 2Gi |
| Access mode | `ReadWriteOnce` |
| Storage class | `hostpath` |
| Namespace | `software-triage` |
| Bound PV reclaim policy | `Retain` |

Separating backups from the database PVC reduces coupling between the live database's storage lifecycle and its backup files.

### Reclaim policy

The default `hostpath` StorageClass provisioned the PV with reclaim policy `Delete`. The bound backup PV was explicitly patched to `Retain`.

`Retain` means that deleting the PVC does not automatically instruct Kubernetes to delete the underlying PV data. It does not make the storage indestructible. The PV may move to a `Released` state and require manual recovery/rebinding, and loss of the Docker Desktop VM, host filesystem, or physical disk can still destroy it.

Keep an independently stored copy outside the cluster. For production, use storage with appropriate durability, access control, encryption, replication, and off-site protection.

### File permissions and least privilege

The PostgreSQL 18 Alpine image uses UID/GID 70 (`postgres`). A temporary Pod mounted the PVC and successfully created, listed, and removed a test file while running as UID/GID 70 and non-root.

The CronJob also runs as UID/GID 70, drops Linux capabilities, disallows privilege escalation, and uses a restrictive file umask (`077`). Completed archive files are set to mode `0600`.

This avoids running the backup container as root and limits access to database dumps, which may contain sensitive application data.

## 5. Creating a PostgreSQL custom-format backup

The project uses PostgreSQL custom archive format:

```sh
pg_dump --format=custom --no-owner --no-acl --file=/path/to/backup.dump "$PGDATABASE"
```

Custom format is suitable for `pg_restore`, supports selective restore, and is compressed by default. The backup container uses the PostgreSQL 18 Alpine image and credentials injected from the existing Kubernetes Secret through environment variables (`PGDATABASE`, `PGUSER`, `PGPASSWORD`, `PGHOST`, `PGPORT`). Do not put credentials directly in manifests or scripts.

The CronJob creates a temporary `.partial` file first. It then:

1. runs `pg_dump`;
2. validates the archive with `pg_restore --list`;
3. renames the partial file to its final `.dump` name only after validation;
4. applies restrictive file permissions;
5. calculates a SHA256 checksum;
6. applies the in-PVC retention rule.

The temporary-file/rename pattern prevents an interrupted dump from appearing under the final successful-backup filename. `pg_restore --list` checks that the archive's table of contents is readable; it does **not** prove the database can be restored. A restore test is still required.

`--no-owner` and `--no-acl` make the archive easier to restore into a test database with a different owner/role setup. They also mean original ownership and grants are not recreated by this dump. Restore permissions and application roles deliberately in the target environment.

## 6. Scheduling and retention

The Kubernetes CronJob uses:

| Setting | Project value |
|---|---|
| Cron expression | `0 */6 * * *` |
| Time zone | `Africa/Lagos` |
| Concurrency policy | `Forbid` |
| Starting deadline | 600 seconds |
| Job backoff limit | 2 |
| Active deadline | 900 seconds |
| Successful Job history | 3 |
| Failed Job history | 3 |
| In-PVC retention | Approximately 14 days |

The retention command deletes matching completed `.dump` files with `find -mtime +13`. `find` uses whole-day age rounding, so this is an approximate 14-day policy, not a precise timestamp-based expiry boundary. Review the policy against backup frequency and recovery objectives before using it for important systems.

The CronJob's `startingDeadlineSeconds: 600` means a run missed by more than ten minutes may not be started late. If Docker Desktop/Kubernetes is stopped during the scheduled time, the backup may be missed. `Forbid` prevents overlapping runs but does not create a backup when the cluster is unavailable.

## 7. Exporting backups outside Kubernetes

### Read-only exporter

A small `postgres-backup-exporter` Deployment mounts `postgres-backups` read-only. It runs as UID/GID 70, has no database credentials, and exists to make PVC files available to the Windows export process.

The read-only mount reduces the risk that the export mechanism can modify or delete backup files. The exporter is an operational helper, not a remote public service; it is accessed using `kubectl exec` and `kubectl cp` under the operator's Kubernetes credentials.

### PowerShell export script

The repository script `scripts/backup/export-postgres-backups.ps1`:

1. locates the exporter Pod;
2. lists completed `software-triage-*.dump` archives on `/backups`;
3. validates each source archive with `pg_restore --list`;
4. obtains the source SHA256 checksum;
5. skips an existing local file only when its checksum matches;
6. refuses to overwrite an existing file with a different checksum;
7. copies new files to a relative staging path;
8. verifies the staged local checksum against the PVC checksum;
9. moves the verified file into the final Windows backup directory.

The relative staging path is intentional. Passing an absolute Windows path such as `C:\...` directly to `kubectl cp` can be misinterpreted because the colon in the drive prefix conflicts with the remote file-spec syntax. Copying into a relative path such as `backups\.staging\<filename>` from the repository root avoids that problem. The script only moves a staged file into the final location after the checksum matches.

### Logging wrapper

`run-postgres-backup-export.ps1` invokes the export script, writes a PowerShell transcript under `backups/logs`, and deletes transcript logs older than 30 days. The database dump directory is excluded by the repository's `.gitignore`; verify this remains true and never stage `.dump` files or logs containing sensitive operational data.

### Windows Task Scheduler

A task named `Software Triage PostgreSQL Backup Export` was registered with four daily triggers in the Windows local time zone:

| Windows local time | Intended operation |
|---|---|
| 00:20 | Export backups |
| 06:20 | Export backups |
| 12:20 | Export backups |
| 18:20 | Export backups |

The Kubernetes CronJob is scheduled at 00:00, 06:00, 12:00, and 18:00 in `Africa/Lagos`; the Windows task is offset by 20 minutes.

Task settings used include `StartWhenAvailable`, `MultipleInstances = IgnoreNew`, a 30-minute execution limit, and up to three restarts at five-minute intervals. The task runs under the interactive Windows user because it needs that user's Docker Desktop/Kubernetes context.

**Operational dependencies:** Windows must be awake, the relevant user session available, Docker Desktop/Kubernetes running, the exporter Pod ready, and `kubectl` configured for the correct cluster. `StartWhenAvailable` can start a missed Windows task when the machine becomes available; it cannot make a backup that the Kubernetes CronJob never created because the cluster was stopped.

**Verified scheduled cycles (November 12, 2026):** two Kubernetes-created backup archives were found on the backup PVC and their Windows copies were present:

| Archive timestamp (UTC in filename) | Kubernetes backup time (Africa/Lagos) | Windows copy time (local) | Evidence |
|---|---|---|---|
| `software-triage-20261112T045958Z.dump` | approximately 06:00 | 06:20:07 | PVC archive and Windows copy existed; local file size was 146,887 bytes. |
| `software-triage-20261112T110015Z.dump` | approximately 12:00 | 12:20:16 | PVC archive and Windows copy existed; local file size was 146,887 bytes. |

The corresponding Kubernetes Job objects were `postgres-backup-29907660` and `postgres-backup-29908020`, both with `Complete` status. These observations confirm two time-triggered backup/export cycles. After a later Docker Desktop restart, `kubectl logs` could no longer retrieve the old Job Pod logs because the underlying `/var/log/pods/...` files were gone. The Job objects and backup files remained. This illustrates that Kubernetes Job status is not durable log retention; preserve important evidence outside the cluster.

**Task Scheduler test after the exporter-startup fix:** the task was manually started through Task Scheduler on November 13 at 01:01:01. Its final `LastTaskResult` was `0`; the transcript showed all four then-known archives being checksum-verified and skipped because matching local copies already existed. This verifies the Task Scheduler execution path after the script change, but it was a manually initiated task run rather than a new time-triggered execution.

### Windows retention

The CronJob applies retention on the PVC. The current Windows export script does **not** delete old local `.dump` files. Local backups therefore accumulate until a separate Windows retention policy is introduced. Do not mirror the PVC deletion policy onto the only external recovery copy without defining the required retention and recovery objectives.

## 8. Restore and verification procedure

A backup should not be considered proven solely because the file exists or `pg_restore --list` can read it. Periodically restore an archive into a separate database and verify the contents.

### Safe restore-test pattern

1. Choose a known backup file and record its SHA256.
2. Verify the archive using `pg_restore --list`.
3. Confirm the test database name does not already exist. Do not overwrite an existing test database without reviewing it.
4. Create a new, separate test database.
5. Restore with `pg_restore --exit-on-error --no-owner --no-acl`.
6. Verify database size, schema/tables, migration history, and representative application data.
7. Compare selected row counts against the source as of the backup time. Differences may be expected if the live database has changed since the dump was taken.
8. For a complete recovery exercise, configure an isolated application instance to use the restored database and test authentication and representative workflows.
9. Retain the restore-test database until verification is complete; then remove it deliberately according to the test data policy.

### Example restore command

```sh
createdb -U "$PGUSER" restore_test_database
pg_restore --exit-on-error --no-owner --no-acl \
  -U "$PGUSER" \
  -d restore_test_database \
  /path/to/backup.dump
```

Do not restore over the live application database during a routine verification exercise.

### PowerShell and `kubectl exec` quoting

Nested quoting through PowerShell, `kubectl exec`, `sh -c`, and SQL was error-prone in the implementation. Directly invoke `psql` after `--` when possible:

```powershell
$pgUser = (kubectl exec -n software-triage postgres-0 -- printenv POSTGRES_USER | Out-String).Trim()
kubectl exec -n software-triage postgres-0 -- psql -X -U $pgUser -d postgres -Atc "SELECT datname FROM pg_database ORDER BY datname;"
```

For each important command, check `$LASTEXITCODE`. PowerShell pipelines can otherwise obscure whether a child process failed.

## 9. Validation evidence from this implementation

### Manual backup and restore

- Two older custom-format archives were inspected successfully with `pg_restore --list`.
- A fresh manual custom-format dump was created and copied to Windows.
- Local and in-Pod SHA256 values matched.
- The dump was restored into a separate `software_triage_restore_test` database.
- The restored database contained 18 public application tables and 29 Django migration records.
- Selected table row counts matched the original database at comparison time.

### Automated CronJob backup and restore

A manually triggered Job created:

```text
software-triage-20261111T142813Z.dump
```

The backup Job log showed successful `pg_dump`, archive validation, SHA256 generation, and completion. The observed archive was approximately 143.4 KiB (146,887 bytes on the Windows copy).

The observed SHA256 was:

```text
141da9a2f073e1bee3072e4b0bec52158cf8c1ee1a138c9934de68590978ed25
```

The same checksum was observed on the PVC and the Windows copy. The automated archive was restored into `software_triage_cronjob_restore_test` using `--exit-on-error`. Nine selected tables matched the live database at comparison time:

| Table | Live | Restored |
|---|---:|---:|
| `auth_user` | 1 | 1 |
| `tickets_ticket` | 36 | 36 |
| `workflow_workflowrun` | 36 | 36 |
| `agents_agentexecution` | 75 | 75 |
| `events_workflowevent` | 587 | 587 |
| `reviews_classificationreview` | 6 | 6 |
| `reviews_reviewrequest` | 18 | 18 |
| `integrations_actionexecution` | 10 | 10 |
| `django_migrations` | 29 | 29 |

The knowledge document/chunk tables were empty in the earlier manual restore comparison and empty in the live database at that point. The row-count comparison is evidence for the selected tables, not a byte-for-byte comparison of the entire PostgreSQL cluster.

The export script was tested in a temporary Windows directory (new-copy branch) and then against the repository backup directory (existing matching file was skipped). The logging wrapper ran successfully. Two time-triggered cycles on November 12 were confirmed by their UTC-stamped PVC archives and Windows copy times at approximately 06:20 and 12:20 Africa/Lagos. Following a Docker Desktop outage, a midnight scheduled backup was missed; the Windows export attempt failed while the exporter was unavailable. A manual recovery Job then created and exported a fresh archive with a matching SHA256. The corrected PowerShell wrapper was also manually launched through Task Scheduler and completed with `LastTaskResult = 0`, verifying four existing local copies. The first automatic time-triggered run after that script correction remained to be observed.

## 10. Troubleshooting

### CronJob does not run

Inspect the CronJob, schedule, time zone, last schedule time, and events:

```powershell
kubectl get cronjob postgres-backup -n software-triage
kubectl describe cronjob postgres-backup -n software-triage
kubectl get jobs -n software-triage
kubectl get events -n software-triage --sort-by='.lastTimestamp'
```

Check that Kubernetes was running at the scheduled time and that the missed-start window was not exceeded.

### Backup Pod cannot write to the PVC

Confirm the PVC is bound and inspect the volume mount. Check the image's runtime user (`id postgres`) and test write access as the same non-root UID/GID. Do not solve a permission error by running the whole backup process as root without understanding the storage ownership.

### Archive validation fails

Preserve the partial file/logs long enough to diagnose the failure. Check the `pg_dump` exit code, free PVC space, database connectivity, and file ownership. The CronJob's partial-file naming and trap are intended to avoid promoting an incomplete archive to the final `.dump` name.

### `kubectl cp` fails on Windows paths

Use a repository-relative staging path rather than passing an absolute `C:\...` destination. Validate the source archive, copy to staging, compare SHA256, and only then move to the final local directory.

### Local file already exists

The export script should skip an existing file only if its local SHA256 equals the remote checksum. If the hashes differ, stop and investigate. Do not overwrite a potentially valid backup automatically.

### Windows task runs but exports nothing

Inspect `Get-ScheduledTaskInfo`, the latest transcript log, Docker Desktop/Kubernetes status, the current kube context, and the exporter Pod. A successful task can legitimately report zero new copies when all remote backups already exist locally with matching hashes.

### Docker Desktop/Kubernetes unavailable at the scheduled time

The Kubernetes CronJob runs only while the Kubernetes control plane and required Pods are available. In this project, `startingDeadlineSeconds: 600` allows a missed run to start only within its configured ten-minute deadline. It is not a durable catch-up queue. If Docker Desktop is stopped during a scheduled backup and the cluster returns after that deadline, do not assume Kubernetes will create the missed archive automatically.

A verified incident occurred around the November 13, 2026 midnight run:

- Docker Desktop/Kubernetes was unavailable around the scheduled backup/export window.
- The Windows task's attempted run was recorded at 00:31:31 with `LastTaskResult = 1`. Its transcript showed `You cannot call a method on a null-valued expression.` The original export script called `.Trim()` on the result of `kubectl get pods` without first checking whether a Pod name had been returned.
- After Docker Desktop was started, the exporter Deployment recovered and the revised script successfully waited for the Deployment to become `Available`, safely checked that a non-empty Pod name was returned, and waited for that Pod to become `Ready` before listing backups.
- A one-off recovery Job was created from the existing CronJob template. It completed successfully and created `software-triage-20261112T235459Z.dump`. The timestamp in the filename is UTC; the run occurred at approximately 00:54:59 Africa/Lagos on November 13.
- The archive was validated, assigned SHA256 `675f3e7a1bfea458b64e273f0b19b52e3e06face3fb457646a421d30a1a2c3d5`, copied to Windows, and verified against the PVC checksum. The export log reported one new archive copied and three existing archives verified.
- The Windows task was then manually started again at 01:01. It completed with `LastTaskResult = 0`, verifying the corrected wrapper under Task Scheduler. It found four archives and skipped them because all four local copies already matched.

This was a **manual recovery backup**, not an automatic replay of the missed midnight CronJob. Keep that distinction clear in operational reports and portfolio descriptions.

A practical recovery sequence is:

1. Start Docker Desktop and wait until the intended Kubernetes context is reachable (`kubectl get nodes`).
2. Confirm that the `postgres-backup` CronJob, PostgreSQL Pod, backup PVC, and exporter Deployment exist and are healthy.
3. Inspect the CronJob's last schedule and Job history. Check the backup PVC for a new archive before creating another backup.
4. If the scheduled backup was missed, create a uniquely named one-off Job from the CronJob template:

   ```powershell
   $recoveryJob = "postgres-backup-recovery-$(Get-Date -Format 'yyyyMMddHHmmss')"
   kubectl create job $recoveryJob --from=cronjob/postgres-backup -n software-triage
   kubectl wait --for=condition=complete "job/$recoveryJob" -n software-triage --timeout=180s
   kubectl logs "job/$recoveryJob" -n software-triage
   ```

5. Run `scripts/backup/run-postgres-backup-export.ps1` after the backup Job completes. Confirm the new timestamped archive appears in `backups/` and that the export transcript reports a successful SHA256 match.
6. Check the Windows task result and latest transcript. A Task Scheduler result of `267009` (`0x41301`) means the task is still running; wait for it to finish before interpreting the final result. A completed successful run returns `LastTaskResult = 0`.
7. Record whether the backup was scheduled or manually recovered, including the backup filename, UTC timestamp, local time, Job name, checksum, and export result.

The corrected export script waits for the exporter Deployment to become `Available`, checks the `kubectl get pods` exit code and non-empty Pod name before using it, and waits for the selected Pod to become `Ready`. If the cluster or exporter is still unavailable, it should fail with a clear diagnostic instead of throwing a null-valued `.Trim()` exception.

**Log-retention warning:** after the Docker Desktop restart in this incident, the two completed CronJob objects remained visible, but `kubectl logs job/...` failed because the node's old Pod log files under `/var/log/pods/` no longer existed. For durable audit evidence, export important Job logs to Windows or use centralized log storage; do not rely on Job objects retaining container logs indefinitely.

### Retention / capacity

Monitor PVC usage and local disk usage. PVC retention and Windows local retention are separate policies. Ensure retention does not delete the only copy that satisfies the required recovery point objective.

## 11. Operational checklist

### On initial setup

- [ ] Identify database, PostgreSQL major version, credentials Secret, and data volume.
- [ ] Provision a dedicated backup destination.
- [ ] Set an appropriate reclaim policy and document its limitations.
- [ ] Verify write permissions using the intended non-root identity.
- [ ] Create a scheduled backup job with partial-file handling and validation.
- [ ] Trigger a backup manually and inspect its logs.
- [ ] Calculate and record a checksum.
- [ ] Copy the archive outside the cluster and compare checksums.
- [ ] Restore into a separate database and verify schema and records.
- [ ] Test the application against a restored database in an isolated environment.
- [ ] Configure and test schedules, logs, retries, and retention.

### During routine operations

- [ ] Review backup Job success/failure history.
- [ ] Confirm new backup timestamps and non-zero file sizes.
- [ ] Review checksum/export logs.
- [ ] Confirm external copies are actually on independent storage.
- [ ] Monitor PVC and local disk capacity.
- [ ] Periodically perform a restore test, not just an archive-list check.
- [ ] Review retention and access permissions.

## 12. Project implementation map

| Concern | Reference file/resource |
|---|---|
| Backup PVC | `infra/kubernetes/postgres-backup-pvc.yaml` |
| Backup CronJob | `infra/kubernetes/postgres-backup-cronjob.yaml` |
| Read-only exporter | `infra/kubernetes/postgres-backup-exporter.yaml` |
| Windows export script | `scripts/backup/export-postgres-backups.ps1` |
| Windows logging wrapper | `scripts/backup/run-postgres-backup-export.ps1` |
| Local backup files | `backups/` (ignored by Git) |
| Export logs | `backups/logs/` |
| Windows Scheduled Task | `Software Triage PostgreSQL Backup Export` |

## 13. Remaining improvements

1. Confirm the first automatic time-triggered backup/export cycle after the exporter-script fix.
2. Add an explicit retention policy for Windows local copies.
3. Copy backups to independent/off-device storage (for example, a protected remote object store or a separate backup host) and verify that copy.
4. Back up and document PostgreSQL global roles, Secrets/configuration, uploaded files, and other required application dependencies.
5. Test a complete application recovery in an isolated environment.
6. Define and record recovery point objective (RPO) and recovery time objective (RTO).
7. Consider stronger integrity/authenticity controls if protection against malicious alteration is part of the threat model; a checksum stored alongside a file detects accidental mismatch but is not, by itself, an authenticated tamper-proof record.


## 14. Portfolio evidence and operational reporting

For a concise portfolio case study, preserve screenshots and corresponding logs that demonstrate outcomes rather than only configuration:

1. **Scheduled Windows export:** Task Scheduler triggers/history plus a completed run (`LastTaskResult = 0`) and the corresponding export transcript.
2. **Kubernetes scheduled backup:** CronJob schedule/last schedule, a `Complete` Job, and its backup log showing archive validation and checksum generation. Capture the logs while the Pod still exists.
3. **Restore verification:** original-versus-restored database comparison showing selected application table counts. State the backup timestamp because the live database may have changed since it was taken.
4. **Host downtime and recovery:** evidence of the missed schedule, the manually triggered recovery Job, its successful backup log, the new archive on the PVC, and the matching Windows/PVC SHA256.
5. **Task Scheduler after the fix:** completed task result `0` and transcript showing the exporter availability check and successful synchronization.

Suggested portfolio wording: *Implemented six-hour PostgreSQL logical backups in Kubernetes, validated custom-format archives, tested restoration into an isolated database, and exported verified copies to a Windows host. During a Docker Desktop outage, identified the missed CronJob window, ran a manual recovery backup, hardened the exporter startup checks, and verified the corrected Task Scheduler execution.* Do not describe the manual recovery as automatic CronJob catch-up, and do not describe the Windows copy as off-site protection: it remains on the same physical host unless copied to independent storage.
