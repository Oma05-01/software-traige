# Software Triage Team — Operations Guides

This directory contains reusable engineering guidance for operating the Software Triage Team application on Kubernetes.

The guides are written to explain the **purpose, design choices, implementation patterns, verification methods, and operational limitations** behind the work. They are not intended to be a terminal-session transcript. Project-specific values are included as working examples; review and adapt them before applying the patterns to another environment.

## Guides

| Guide | What it covers |
|---|---|
| [Kubernetes reliability and resource monitoring](./kubernetes-reliability-guide.md) | Health probes, dependency checks, Celery worker monitoring, Metrics Server, resource requests and limits, validation, and troubleshooting. |
| [PostgreSQL backup and recovery](./postgresql-backup-and-recovery-guide.md) | Custom-format database dumps, persistent backup storage, CronJobs, archive validation, checksums, external Windows copies, restore testing, and recovery limitations. |

## How to use these guides

1. Start with the objective and architecture sections to understand the problem being addressed.
2. Use the design considerations to choose an approach suitable for the target cluster. Do not copy project-specific values blindly.
3. Consult the implementation map to identify the relevant Kubernetes manifests and scripts.
4. Use the verification sections to define evidence of success. A resource being created or a Pod being `Running` is not, by itself, proof that the complete application workflow works.
5. Review the troubleshooting and limitations sections before applying changes in production.

## Project context

The reference implementation is a local Docker Desktop Kubernetes cluster running a Django/DRF backend, a Next.js frontend, a Celery worker, PostgreSQL, and Redis. The namespace is `software-triage`. The cluster is a single-node development environment, not a highly available production cluster.

The guides distinguish three kinds of information:

- **General practice:** principles that usually transfer to other Kubernetes applications.
- **Project example:** values and file names observed in this repository.
- **Current status:** work verified during this implementation, along with work that remains unverified or intentionally deferred.

## Current implementation status

### Kubernetes reliability

- Backend liveness and database readiness endpoints are deployed and were verified inside the running Pod.
- Frontend `/healthz` is deployed and was verified with HTTP 200.
- PostgreSQL and Redis probe timeouts were increased after repeated probe timeouts were observed. The replacement Pods became ready with zero restarts at verification time.
- The Celery `inspect ping` readiness probe was removed after repeated timeouts. The worker currently has no custom readiness or liveness probe; its real ticket-processing path was tested successfully.
- Metrics Server 0.9.1 is installed and `kubectl top` works. The local Docker Desktop deployment uses `--kubelet-insecure-tls` because its kubelet serving certificate did not contain the node IP as an IP SAN. This workaround is for local development only.
- Initial resource snapshots were collected. Resource requests and limits were **not** reduced because the sampling period and workload coverage were insufficient for safe tuning.

### PostgreSQL backup and recovery

- A dedicated 2Gi `postgres-backups` PVC was provisioned with `ReadWriteOnce`; its bound PV reclaim policy was changed to `Retain`.
- Backup storage write permissions were verified using UID/GID 70, matching the PostgreSQL image user.
- A six-hour Kubernetes CronJob creates custom-format dumps, validates the archive, writes a checksum, and applies approximately 14-day retention on the PVC.
- A read-only exporter Deployment exposes the backup PVC to a Windows PowerShell export process.
- The export script was tested for copying a missing file, skipping existing matching files, and refusing checksum mismatches. It uses a relative staging path to avoid Windows drive-letter parsing issues in `kubectl cp`; the wrapper writes PowerShell transcripts.
- Two time-triggered Kubernetes backup/export cycles were verified on November 12, 2026 (approximately 06:00/06:20 and 12:00/12:20 Africa/Lagos).
- A CronJob-generated backup was restored into a separate PostgreSQL database. Selected application table counts matched the source database.
- Docker Desktop downtime caused a midnight scheduled backup to be missed. The Windows export attempt failed while the exporter was unavailable; the script was then hardened to wait for the exporter Deployment/Pod and validate the Pod name. A manual recovery Job created a new archive, its SHA256 matched after Windows export, and a subsequent manually started Task Scheduler run completed with `LastTaskResult = 0`. The first automatic time-triggered run after this correction remains to be observed.

## Important boundaries

- A PVC, even with a `Retain` reclaim policy, is not an off-cluster backup. Host, Docker Desktop, or underlying disk loss can still destroy it.
- The current Windows export task depends on the Windows user session, Docker Desktop/Kubernetes availability, and the exporter Pod being available. `StartWhenAvailable` cannot create a backup that a stopped cluster failed to produce; the CronJob's 600-second start deadline limits late catch-up.
- The current CronJob retention policy applies to files on the backup PVC. The Windows export script does not currently prune old `.dump` files from the local `backups/` directory.
- PostgreSQL dumps cover the selected database, not Kubernetes Secrets, environment files, uploaded files outside the database, Redis data, or cluster-wide PostgreSQL roles.
- A database restore and matching table counts are strong database-level evidence, but do not prove a complete disaster-recovery exercise until the application is also started against the restored database and its critical workflows are tested.

## Suggested next improvements

1. Confirm the first automatic time-triggered backup/export cycle after the exporter-script fix.
2. Add a deliberate Windows-side backup retention policy and, ideally, an additional off-device/off-site copy.
3. Test application startup and representative workflows against a restored database in an isolated environment.
4. Define a separate recovery plan for Redis, uploaded files, Kubernetes Secrets/configuration, and other required dependencies.
5. Improve Celery observability with task lifecycle metrics, queue age/depth, failure/retry counts, and persisted workflow execution state rather than relying on a slow remote-control probe.
6. Use longer-duration or higher-frequency metrics before adjusting CPU and memory requests/limits.
