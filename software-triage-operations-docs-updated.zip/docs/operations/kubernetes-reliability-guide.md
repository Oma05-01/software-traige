# Kubernetes Reliability and Resource Monitoring Guide

## 1. Purpose

This guide describes a practical approach to making a multi-component application more observable and resilient on Kubernetes. The central goal is to help Kubernetes distinguish between:

- a process that has not started successfully;
- a process that has stopped functioning and should be restarted;
- an application instance that is alive but cannot safely serve requests; and
- a background worker whose task-processing health must be measured separately from HTTP service health.

It also explains how to establish a resource-usage baseline before changing CPU and memory requests or limits.

The examples reflect the Software Triage Team deployment. They should be treated as reference values, not universal defaults.

## 2. Reference architecture

The application runs in the `software-triage` namespace on a single-node Docker Desktop Kubernetes cluster.

| Component | Workload type | Main responsibility | Dependency/communication |
|---|---|---|---|
| Frontend | Deployment | Next.js user interface | Calls backend through the configured internal URL/rewrite |
| Backend | Deployment | Django/DRF API, workflow creation and persistence | PostgreSQL; dispatches background work through Redis/Celery |
| Worker | Deployment | Executes Celery agent and integration tasks | Redis broker; PostgreSQL through application code |
| PostgreSQL | StatefulSet | Durable application database | Persistent volume claim |
| Redis | Deployment | Celery broker and Redis persistence | Persistent volume claim; AOF enabled |
| Metrics Server | Deployment in `kube-system` | Supplies short-term resource metrics to Kubernetes | Scrapes kubelet resource metrics |

The frontend and backend expose HTTP endpoints. The Celery worker does not expose an HTTP service in this design. PostgreSQL and Redis use their own command-based health checks.

## 3. Health-probe concepts

Kubernetes provides three probe types. They answer different questions and should not be made interchangeable merely for convenience.

### Startup probe

Use a startup probe when an application may need significant time to initialise. While the startup probe has not succeeded, Kubernetes does not run the liveness or readiness probes. This avoids treating a slow but valid startup as a dead process.

### Liveness probe

A liveness probe should answer: **is this container's process still functioning such that it should remain running?**

Keep it independent of transient external dependencies where possible. If liveness depends on a database or broker, a temporary dependency outage can cause Kubernetes to restart an otherwise functioning process repeatedly. That can amplify an outage.

### Readiness probe

A readiness probe answers: **should this Pod be considered ready for the type of work Kubernetes routes to it?**

For HTTP services behind a Kubernetes Service, readiness normally controls whether the Pod is included as a ready Service endpoint. Readiness failure does not itself restart a container.

A readiness probe on a queue-consuming worker has different semantics. It does not automatically pause Celery consumption. In this project, there is no Kubernetes Service routing normal user traffic to the worker, so a simple `Ready` status is not a complete indication of task-processing health.

## 4. Probe design used in this project

### 4.1 Django backend: separate process health from database readiness

Two endpoints were implemented in `backend/apps/common/views.py` and routed in `backend/apps/common/urls.py`:

| Endpoint | Responsibility | Dependency check |
|---|---|---|
| `/api/health/live/` | Returns a basic successful response when the API process is serving requests | Does not query PostgreSQL |
| `/api/health/` | Executes a simple database check (`SELECT 1`) and reports dependency readiness | Checks PostgreSQL; returns an unavailable response when the check fails |

The backend Deployment uses the liveness endpoint for startup/liveness and the database-aware endpoint for readiness.

**Why this separation matters:** a database outage should cause the API to stop being considered ready, but it should not automatically cause Kubernetes to restart the API process. The application can remain alive while the dependency is recovering.

The health view tests were run successfully (3 tests), and both deployed endpoints returned HTTP 200 when PostgreSQL was healthy.

### 4.2 Next.js frontend: an independent health endpoint

A small App Router route was added at `frontend/src/app/healthz/route.ts`. It returns HTTP 200 with a minimal JSON status response. The frontend startup, readiness, and liveness probes use `/healthz`.

The endpoint intentionally does not call the backend. This means frontend process health is not conflated with API availability. Functional end-to-end availability still depends on the backend and should be measured separately.

The production frontend build and lint checks passed, the image was rebuilt, and the endpoint returned HTTP 200 inside the deployed Pod.

### 4.3 PostgreSQL: check database acceptability, not a full application query

The PostgreSQL probes use `pg_isready` with the configured database user and database name. The project settings after adjustment were:

| Probe | Command | Period | Timeout | Failure threshold |
|---|---|---:|---:|---:|
| Startup | `pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB"` | 10s | 5s | 30 |
| Readiness | Same | 10s | 10s | 6 |
| Liveness | Same | 15s | 10s | 6 |

The StatefulSet uses a 60-second termination grace period. After the manifest update, the StatefulSet rolled out, `postgres-0` was `Running` and `Ready` with zero restarts, and `pg_isready` reported that the server was accepting connections.

`pg_isready` checks whether PostgreSQL is accepting connections; it does not prove that every application query or migration will work. Application-level database checks should remain part of application tests and monitoring.

### 4.4 Redis: use a lightweight PING check and allow for local I/O delays

Redis probes use `redis-cli ping`:

| Probe | Period | Timeout | Failure threshold |
|---|---:|---:|---:|
| Readiness | 10s | 5s | 6 |
| Liveness | 15s | 5s | 6 |

The Redis Deployment uses `Recreate` because a single Redis instance mounts one `ReadWriteOnce` data volume. Avoid overlapping instances attempting to use the same data directory during replacement.

The deployed Redis Pod returned `PONG`, reported `appendonly yes`, loaded its existing RDB base and incremental AOF files, and became ready with zero restarts.

Redis had previously logged AOF fsync latency warnings (`Asynchronous AOF fsync is taking too long`). Longer probe timeouts reduce sensitivity to brief delays, but they do not fix underlying disk latency. Continue monitoring storage performance.

### 4.5 Celery worker: do not use an unreliable remote-control command as a liveness test

The worker initially had a readiness probe based on:

```text
celery -A config inspect ping --timeout=5
```

The command worked when run manually, but Kubernetes later recorded repeated probe timeouts (48 failures in approximately 38 minutes in the observed event window). The command launches a separate Celery CLI process and relies on broker/remote-control communication. A timeout does not necessarily mean the worker's main process has died.

The probe was removed. The current worker has no custom readiness or liveness probe. The Deployment uses one replica, concurrency 1, and a 60-second termination grace period. After the change, the replacement Pod was `Running` and `Ready` with zero restarts, and its logs showed connection to Redis and Celery's `ready` message.

**Important limitation:** without a custom readiness probe, Kubernetes mainly reflects container process state. It does not independently prove that the worker is consuming messages or completing tasks. Also, because the worker is not behind a Kubernetes Service, readiness does not control queue consumption.

Better future worker health signals include:

- task success/failure and retry counters;
- time since the last successful task;
- queue depth and oldest-message age;
- active/reserved task counts;
- task duration by task/agent type;
- Celery worker heartbeats or a dedicated health endpoint/exporter;
- persisted workflow and agent-execution states, including stuck queued/running work.

Use Celery remote-control commands for operator diagnostics when appropriate, not as the sole proof of worker health. Any periodic check should be tested under broker latency and outage conditions before it is made a Kubernetes restart condition.

## 5. Initial resource requests and limits

The following values were configured at the time of this review:

| Component | CPU request | Memory request | CPU limit | Memory limit |
|---|---:|---:|---:|---:|
| Backend | 100m | 256Mi | 1 CPU | 1Gi |
| Frontend | 100m | 256Mi | 1 CPU | 1Gi |
| Worker | 100m | 256Mi | 1 CPU | 1Gi |
| PostgreSQL | 100m | 256Mi | 1 CPU | 1Gi |
| Redis | 50m | 64Mi | 500m | 512Mi |

Requests influence scheduling and resource guarantees; limits cap resource consumption. A CPU limit can throttle a container, while a memory limit can lead to an OOM kill if the process exceeds it. These values should be selected from representative workload observations, not from a single idle reading.

### 5.1 Metrics Server

Metrics Server 0.9.1 was installed from the upstream release manifest on Kubernetes 1.36.1. It enabled:

```powershell
kubectl top nodes
kubectl top pods -n software-triage --containers
```

The Docker Desktop kubelet certificate did not contain the node IP (`192.168.65.3`) as an IP SAN. Metrics Server therefore failed TLS certificate verification and did not become ready. For this local development cluster only, the Deployment was configured with:

```text
--kubelet-insecure-tls
```

This disables verification of the kubelet serving certificate. **Do not carry this setting into production.** Production clusters should use trusted kubelet serving certificates and configure the appropriate CA/trust chain.

The Metrics Server manifest used a 15-second metric resolution. Metrics Server is intended to provide short-term resource metrics for Kubernetes, not a durable historical monitoring store.

### 5.2 Observed baseline (short sample, not a capacity test)

An initial snapshot showed approximately:

| Component | CPU | Memory |
|---|---:|---:|
| Backend | 9m | 122Mi |
| Frontend | 3m | 69Mi |
| PostgreSQL | 17m | 26Mi |
| Redis | 17m | 7Mi |
| Worker | 16m | 88Mi |

Five additional samples during ordinary/test activity showed worker CPU ranging from 11m to 115m, with memory around 88Mi. Node CPU varied approximately from 24% to 51%, and node memory remained around 53%.

The node had 4 CPUs and approximately 7.6Gi allocatable memory. At the time of `kubectl describe node`, total pod requests were approximately 35% of CPU and 19% of memory; limits were approximately 112% of CPU and 63% of memory. CPU limits may be overcommitted by design, but simultaneous CPU-bound work can compete for CPU time.

These were short observations. The actual ticket workflow completed in seconds, shorter than the Metrics Server collection interval, so the samples cannot be treated as an accurate peak measurement of that workflow. Resource requests and limits were therefore left unchanged.

### 5.3 Recommended tuning method

Before changing resources:

1. Define representative workload scenarios (idle, normal tickets, concurrent tickets, heavy agent/integration jobs).
2. Collect metrics over a sufficiently long period and include peak periods.
3. Use application/task metrics for short jobs; 15-second container samples can miss seconds-long spikes.
4. Observe CPU throttling, OOM kills, restarts, queue age, latency, and task failures alongside CPU/memory usage.
5. Adjust requests and limits incrementally, then repeat the workload test.
6. Keep a rollback path and record why each adjustment was made.

Prometheus or another monitoring stack can provide historical, more frequent metrics. Application instrumentation is still needed for task-level behaviour.

## 6. Troubleshooting patterns observed

### Probe timeouts in PostgreSQL and Redis

Repeated probe timeout events were observed before the probe timeouts were increased. The previous PostgreSQL and Redis containers later showed graceful shutdowns at nearly the same time: PostgreSQL logged a fast shutdown request and Redis logged SIGTERM, both exiting with code 0. This points to an externally requested shutdown/restart rather than proving an application crash. The exact trigger was not established.

When investigating similar incidents, correlate:

- Pod events and restart counts;
- `Last State`, termination reason and exit code;
- current and previous container logs (`kubectl logs --previous`);
- node conditions and resource allocation;
- Docker Desktop/host restart history;
- storage latency and filesystem events.

Do not assume every restart is caused by a liveness probe or by OOM. Use the termination reason and timestamps.

### Worker probe timeout

If `celery inspect ping` times out, inspect the main worker logs, Redis availability, task events, queue state, and actual workflow records before concluding that the worker process is dead. Avoid using a broker-dependent probe as liveness unless its failure semantics are intentionally designed and tested.

### `kubectl top` reports Metrics API unavailable

Check whether Metrics Server exists and is ready, and inspect:

```powershell
kubectl get apiservice v1beta1.metrics.k8s.io
kubectl get pods -n kube-system -l k8s-app=metrics-server
kubectl logs deployment/metrics-server -n kube-system --tail=100
kubectl describe apiservice v1beta1.metrics.k8s.io
```

A common cause is failed kubelet scraping. Inspect the exact TLS/network error rather than adding insecure flags by default.

### PowerShell output/quoting around `kubectl exec`

Nested PowerShell, `kubectl exec`, shell, and SQL quoting can make commands difficult to diagnose. For PostgreSQL queries, invoking `psql` directly after `--` was more reliable than adding an additional `sh -c` layer:

```powershell
$pgUser = (kubectl exec -n software-triage postgres-0 -- printenv POSTGRES_USER | Out-String).Trim()
kubectl exec -n software-triage postgres-0 -- psql -X -U $pgUser -d postgres -Atc "SELECT datname FROM pg_database ORDER BY datname;"
```

Always inspect `$LASTEXITCODE` after commands whose success matters.

## 7. Verification checklist

Use this checklist after implementing or changing reliability settings:

- [ ] Backend liveness is dependency-independent.
- [ ] Backend readiness checks only dependencies needed to serve requests.
- [ ] Frontend health endpoint does not unintentionally depend on backend availability.
- [ ] Startup thresholds accommodate realistic initialisation time.
- [ ] Liveness is not tied to a transient external dependency without a deliberate reason.
- [ ] Probe timeout/period/failure thresholds are validated against observed latency.
- [ ] Worker monitoring reflects task-processing health, not just a CLI command response.
- [ ] Deployment/StatefulSet rollout succeeds.
- [ ] Pods are ready and restart counts are inspected.
- [ ] A real user-facing workflow completes and its persisted result is checked.
- [ ] Metrics API is available and workload measurements are collected over representative periods.
- [ ] Resource changes are evidence-based and documented.

## 8. Project implementation map

| Concern | Reference file/resource |
|---|---|
| Backend health views | `backend/apps/common/views.py` |
| Backend health URL routing | `backend/apps/common/urls.py` |
| Backend probes | `infra/kubernetes/backend.yaml` |
| Frontend health route | `frontend/src/app/healthz/route.ts` |
| Frontend probes | `infra/kubernetes/frontend.yaml` |
| Worker deployment | `infra/kubernetes/worker.yaml` |
| PostgreSQL StatefulSet/probes | `infra/kubernetes/postgres.yaml` |
| Redis Deployment/probes | `infra/kubernetes/redis.yaml` |
| Metrics Server | `infra/kubernetes/metrics-server.yaml` |

## 9. Current status and next steps

The backend, frontend, PostgreSQL, Redis, and worker changes were deployed. A real ticket was processed by the Receptionist, Debugger, and Support Representative; the workflow reached the expected human-review stage. At the latest verification, the application Pods were all `Running`/`Ready` with zero restarts, and the namespace event query returned no retained warning/failure events at that point.

Remaining work is not to add more probes indiscriminately. It is to improve task-level worker observability, gather representative metrics, monitor Redis storage latency, and verify long-term dependency stability. Resource tuning remains deferred until adequate measurements exist.
